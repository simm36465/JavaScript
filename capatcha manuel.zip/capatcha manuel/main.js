

/**
*****************************
projet | maneul capatcha
product by : mohammed laksir
date :8/5/2016
contact me : https://www.facebook.com/name.hide36465
*****************************

=> meme content html in javascript just active this and delete content html sauf <i class="fa fa-refresh>

var myMainDiv = document.getElementById("content");
secondDiv = document.createElement("div");
secondDiv.setAttribute("id", "ScreenContent");
 Myinput = document.createElement("input");
Myinput.setAttribute("id", "bareCapa");
Myinput.setAttribute("type", "text");
Myinput.setAttribute("placeholder", "enter the capatcha bellow ...");
MyButton = document.createElement("button");
MyButton.setAttribute("id", "btn");
MyButton.textContent = "Valide";


myMainDiv.appendChild(secondDiv);
myMainDiv.appendChild(Myinput);
myMainDiv.appendChild(MyButton);
MyButton.onclick = confirmation();*/

//main code 

function reCapatcha(){
var mainCapatcha = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X', 'Y','Z',1,2,3,4,5,6,7,8,9,0,'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y', 'z'];
        var a = mainCapatcha[Math.floor(Math.random() * 62)];
        var b = mainCapatcha[Math.floor(Math.random() * 62)];
        var c = mainCapatcha[Math.floor(Math.random() * 62)];
        var d = mainCapatcha[Math.floor(Math.random() * 62)];
        var e = mainCapatcha[Math.floor(Math.random() * 62)];
        var f = mainCapatcha[Math.floor(Math.random() * 62)];
        var g = mainCapatcha[Math.floor(Math.random() * 62)];
        var h = mainCapatcha[Math.floor(Math.random() * 62)];
            var capatcha = a+b+c+d+e+f+g+h;
    document.getElementById("ScreenContent").innerHTML = capatcha;
    }
reCapatcha();
function confirmation() {
    var capa = document.getElementById("ScreenContent").innerHTML;
    var    MyInput = document.getElementById("bareCapa");
    //script de confirmation
    if (capa == MyInput.value){
        swal("Capatcha correct", "God job", "success") // if capatcha correct
        MyInput.style.outlineColor="#10ff00";
    }else {
        swal("Capatcha incorrect !", "Try again !") // if capatcha incorrect
        MyInput.style.outlineColor="red";
    }
    
}


